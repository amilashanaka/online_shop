$(document).ready(function () {

    // $("#product-form").validate({
    //     rules: {
    //         name: "required",
    //     },
    //     messages: {
    //         name: "<li style='font-weight: 100 !important;'>Please Add Product Name </li>",
    //     },
    //     errorLabelContainer: "#summary .error_element",
    // }); 

});