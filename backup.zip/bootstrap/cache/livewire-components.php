<?php return array (
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
);